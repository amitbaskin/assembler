/* this file is used to translate the instructions and data collected into machine code to output */

#include <string.h>
#include "wordTrans.h"
#include "opDef.h"
#include "opWordGetSet.h"
#include "sWordGetters.h"


int transDest(int ref){
    if (ref == R_NONE) return 0;
    return (ref - 1) << DEST_BITS_PREFIX;
}

int transSrc(int ref){
    if (ref == R_NONE) return 0;
    return (ref - 1) << SRC_BITS_PREFIX;
}

int transFunct(int i){
    return getFunct(i) << FUNCT_BITS_PREFIX;
}

int transOpcode(int i){
    return getOpCode(i) << OPCODE_BITS_PREFIX;
}

int transReg(int reg){
    return 1 << reg;
}

int transOp(opWord *op){
    int dest = transDest(getOpDest(op));
    int src = transSrc(getOpSrc(op));
    int funct = transFunct(getOpIndexByObject(op));
    int opCode = transOpcode(getOpIndexByObject(op));
    return dest + src + funct + opCode;
}

void printWordToFile(FILE *fp, int word){
    void *ptr = NULL;
    char *str = NULL;
    char *orgStr = NULL;
    unsigned long len;
    getAlloc(sizeof(int)+1, &ptr);
    str = (char *) ptr;
    orgStr = str;
    sprintf(str, INT_WORD_FORMAT, word);
    len = strlen(str);
    str[len] = ' ';
    str += (len - WORD_LEN);
    fprintf(fp, "%s", str);
    freeHelper(orgStr);
}

void printAddressToFile(FILE *fp, sWord *word){
    fprintf(fp, ADDRESS_FORMAT, getSWordAddress(word));
}

void printAddressTypeToFile(FILE *fp, sWord *word){
    fprintf(fp, "%c\n", getSWordAddressType(word));
}
