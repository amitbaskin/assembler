#include "generalUtils.h"
#ifndef ASSEMBLER_ASSEMBLER_H
#define ASSEMBLER_ASSEMBLER_H
result assemble(char *fName);
#endif
