#include "wordId.h"
#include "generalUtils.h"
#ifndef ASSEMBLER_STR_DATA_H
#define ASSEMBLER_STR_DATA_H
result isStrScenario(char *word, char **line, label *lab, sWordLst *dataLst, labelLst *labLst);
#endif
