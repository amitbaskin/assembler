#include "wordId.h"
#include "generalUtils.h"
#ifndef ASSEMBLER_NUMS_DATA_H
#define ASSEMBLER_NUMS_DATA_H
result isNumDataScenario(char *word, char **line, label *lab, sWordLst *dataLst, labelLst *labLst);
#endif
