#include "wordId.h"
#include "generalUtils.h"
#ifndef ASSEMBLER_U_WORD_UTILS_H
#define ASSEMBLER_U_WORD_UTILS_H
result initUWord(uWord **word);
void freeUWord(sWord *word);
#endif
