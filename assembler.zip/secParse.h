#include "wordId.h"
#include "generalUtils.h"
#ifndef ASSEMBLER_SEC_PARSE_H
#define ASSEMBLER_SEC_PARSE_H
result parseInstLst(sWordLst *instLst, labelLst *labLst);
#endif
